Bust A Cap in Your App.

Setup:
(1) Copy the Exe from the zip file to anywhere on your computer.

(2) Make a shortcut to wherever you put the exe and put it in your "All Programs...Startup" folder startup folder.

(3) Append a distinctive string from the app's exe or title bar name on the end of the command line ("Target") in the shortcut.
For example the target value might look like this: C:\Users\jfuex\Desktop\BustACapInYourApp.exe Revit

(4) if you want to run it immediately and test it, just click the shortcut directly.

Using it: 
* Once it is running any time an app with the string you added in step 3 is active it will turn on caps lock and show a info buble from the system tray icon (looks like a gun)
* If you make another app active it will turn caps lock back off and give you another info bubble letting you know.
* You can right click the gun and select exit to turn it off.


Future versions:
If you don't like the bubbles, I can disable that and send you a new EXE. I just thought it was handy to warn you. It was useful for testing because my keyboard doesn't have a caps lock light.

No support for multiple apps yet (unless they have the same string in name. Would be easy to add though.



